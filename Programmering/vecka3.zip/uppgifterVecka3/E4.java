/*
The program reads a sequence of integers and prints back out
the integers to standard output, except that it removes repeated
values if they appear consecutively.

For example, if the input is 1 2 2 1 5 1 1 7 7 7 7 1 1,
your program should print out 1 2 1 5 1 7 1.

*/

/*

Your task is to complete the program after
 // Your code here

 ** Optional: **
 ***************
 If the user presses Ctrl D without providing any numbers the program
 has nothing to do: there should be no output and the program should
 terminate quitely.

  Make sure your program has this behaviour.
*/
import java.util.Scanner;
public class E4{
  public static void main(String[] args) {
      Scanner data = new Scanner(System.in);
      // Your code here
      if(data.hasNext()){

        int i = 0;
        int prev_number = 0;
        String output = "";

        while(data.hasNext()){
          int curr_digit = data.nextInt();
          if(i != 0){
            if(curr_digit != prev_number){
              output += curr_digit + " ";
              prev_number = curr_digit;
            }
          } else{
            output = curr_digit + " ";
          }
          i++;
        }
        System.out.println(output);
      }
  }
}
