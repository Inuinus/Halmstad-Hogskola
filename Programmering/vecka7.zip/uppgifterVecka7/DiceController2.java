/*
  This is exercise 7.

  Copy the code from DiceController.java and modify the code so that
  it works with DiceView2 instead of DiceView.

*/

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DiceController2 implements ActionListener{

  // Your code here: the instance variables
  private DiceModel c;
  private DiceView2 d;

  // Your code here: the constructor
  public DiceController2(DiceModel cm, DiceView2 dv){
      c = cm;
      d = dv;
      System.out.println(c.read());
  }

  // Your code here: the method actionPerformed
  public void actionPerformed(ActionEvent e){
      c.roll();
      d.repaint();
      System.out.println(c.read());
  }
}
