/*
  This is exercise 7.

  Copy the code from E5.java and modify the code so that
  it works with DiceView2 and DiceController2.

*/

import javax.swing.JFrame;
import javax.swing.JButton;

import java.awt.BorderLayout;

public class E8{
  public static void main(String[] cmdLn){
    // Your code here.
    JFrame f = new JFrame("Counter");
    JButton count = new JButton("Roll");

    DiceModel c = new DiceModel();
    DiceView2 cv = new DiceView2(c);

    count.addActionListener(new DiceController2(c, cv));

    f.setLayout(new BorderLayout());
    f.add(count, BorderLayout.SOUTH);
    f.add(cv, BorderLayout.CENTER);
    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    f.pack();
    f.setVisible(true);

  }
}
