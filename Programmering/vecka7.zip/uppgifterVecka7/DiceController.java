/*
  This is the fourth exercise

  Complete the data type DiceController by modifying the class
  CounterController we presented in the lecture.
  (See the code in comments below the exercise)

    - Make sure it uses a DiceModel and a DiceView instead of a
      CounterModel and a CounterView.
*/

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DiceController implements ActionListener{
  // Your code here.
  private DiceModel c;
  private DiceView d;

  public DiceController(DiceModel cm, DiceView dv){
      c = cm;
      d = dv;
      System.out.println(c.read());
  }

  public void actionPerformed(ActionEvent e){
      c.roll();
      d.repaint();
      System.out.println(c.read());
  }
}


/*

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CounterController implements ActionListener{

    private CounterModel c;

    public CounterController(CounterModel cm){
        c = cm;
        System.out.println(c.read());
    }

    public void actionPerformed(ActionEvent e){
        c.inc();
        System.out.println(c.read());
    }
}

*/
