/*
  The exercises are
    1) To modify the implementation of toString
    2) To add methods for the operations
          scale, minus, abs, conjugate and quotient
  The instructions are in comments before each task.

*/
public class Complex{

  private final double re;
  private final double im;

  public static final Complex I = new Complex(0,1);

  public Complex(double real, double imag){
    re = real;
    im = imag;
  }

  public Complex(double real){
    re = real;
    im = 0;
  }

  public Complex plus(Complex that){
    double real = this.re + that.re;
    double imag = this.im + that.im;
    return new Complex(real, imag);
  }

  public Complex times(Complex that){
    double real = this.re * that.re - this.im * that.im;
    double imag = this.re * that.im + this.im * that.re;
    return new Complex(real, imag);
  }

  public boolean equals(Complex that){
    return this.re == that.re && this.im == that.im;
  }

  /*
    Exercise:
     Modify the implementation so that if the imaginary part is a negative
     number im, the resulting string is
       re - |im| instead of re + im (where im has a leading -).
  */
  public String toString(){
    if (im == 0){return ""+re;}
    if (re == 0){return im + "i";}
    if(im < 0){return re + " - " + Math.abs(im) + "i";}
    return re + " + " + im + "i";
  }

  /*
    Exercise:
    Complete the definition of scale to be the operation that multiplies a
    real number by a complex number:
    See the lecture on 'komplexatal' in the course 'Algebra och diskret
    matematik', Räkneregler för komplexatal.
          xz = xa+ixb for z a complex number a + ib and x a real number
  */
  public Complex scale(double x){
    // Your code here.
    double real = x*re;
    double imag = x*im;
    Complex com = new Complex(real, imag);
    return com;
  }

  /*
    Exercise:
    Complete the definition of minus according to
       z1 - z2 = z1 + (-1)z2
    (See the lecture on 'komplexatal' in the course 'Algebra och diskret
    matematik', Räkneregler för komplexatal)
  */
  public Complex minus(Complex that){
    // Your code here.
    double real = this.re + (-1*that.re);
    double imag = this.im + (-1*that.im);
    return new Complex(real, imag);
  }

  /*
    Exercise:
    Complete the definition of abs according to
     |z| = sqrt(a^2 + b^2) for z a complex number a + ib
     (See the lecture on 'komplexatal' in the course 'Algebra och diskret
     matematik', Absolutnelopp och konjugat)
  */
  public double abs(){
    // Your code here.
    double abs = Math.sqrt(Math.pow(this.re,2) + Math.pow(this.im,2));
    return abs;
  }

  /*
    Exercise:
    Complete the definition of conjugate according to
    z conjugate = a - ib for z a complex number a + ib
    (See the lecture on 'komplexatal' in the course 'Algebra och diskret
     matematik', Absolutnelopp och konjugat)
  */
  public Complex conjugate(){
    // Your code here.
    return new Complex(this.re,-1*this.im);
  }

  /*
    Exercise:
    Complete the definition of quotient according to
    z1/z2 = z1 (z2 conjugate)/|z2|^2
    (See the lecture on 'komplexatal' in the course 'Algebra och diskret
     matematik', Division)
  */
  public Complex quotient(Complex that){
    // Your code here.
    Complex z1 = new Complex(this.re, this.im);
     double z2ConjSqr = Math.pow(that.re,2) + Math.pow(that.im,2);
     double realPart = (z1.re * that.re) + (z1.im * that.im);
     double imPart = (z1.im * that.re) - (z1.re * that.im);
     double real = (realPart)/(z2ConjSqr);
     double imag = (imPart)/(z2ConjSqr);

     /*
     a = z1.re, b = z1.im
     c = that.re, d = that.im
     */

     return new Complex(real,imag);
  }


  public static void main(String[] args) {
    System.out.println("i*i = " + I.times(I));

    Complex z1 = new Complex(2, 3);
    Complex z2 = new Complex(5, -4);
    System.out.println(z1 + " plus " + z2 + " = " + z1.plus(z2));

    Complex z3 = new Complex(5,15);
    Complex z4 = new Complex(1,-3);
    System.out.println(z3 + " quot " + z4 + " = " + z3.quotient(z4));
  }
}
