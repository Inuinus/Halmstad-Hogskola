/*
The class Picture has to be in the same directory as this program.
It is included in the zip file.

The program reads two integer values w and h from the command line
and creates a picture of size w x h with random colors.

A random color is a color with random red, green and blue components.

The program ends by showing the picture in a window.

The file e4.png is the result of saving the picture shown
by running

java E4 500 300
*/
import java.awt.Color;
public class E4{
  public static void main(String[] args) {
    // Your code here.
    int w = Integer.parseInt(args[0]);
    int h = Integer.parseInt(args[1]);

    Picture p = new Picture(w,h);

    for (int i = 0; i < w; i++) {
      for (int j = 0; j < h; j++) {
        Color randomColor = new Color((int)(Math.random()*255 + 1), (int)(Math.random()*255 + 1), (int)(Math.random()*255 + 1));
        p.set(i,j, randomColor);
      }
    }
    p.show();
  }
}
