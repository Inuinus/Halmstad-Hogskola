/*
The program demonstrates a color and its complement.
It uses a static method complement and draws a square with
the original color and a smaller overlapped square
with the complement.

Your task is to complete the method complement.

The image e3.png shows the result of running
java E3
*/
import java.awt.Color;
public class E3{

  /*
  The method returns a color where each component is calculated
  as 255 - the corresponding component of the argument.
  */
  public static Color complement(Color c){
    // Your code here
    // Remove return null.
    Color a =  new Color(255 - c.getRed(), 255 - c.getGreen(), 255 - c.getBlue());
    return a;
  }

  /*
  Demonstrates the complement of red.
  */
  public static void main(String[] args) {
    Color col = new Color(255,0,0);
    StdDraw.setPenColor(col);
    StdDraw.filledSquare(0.5,0.5,0.25);
    StdDraw.setPenColor(complement(col));
    StdDraw.filledSquare(0.5,0.5,0.125);
  }

}
