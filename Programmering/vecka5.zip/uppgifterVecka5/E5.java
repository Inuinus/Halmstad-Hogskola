/*
The program reads the name of a file from the command line.
The file should be a PNG, GIF, or JPEG file containing an image.

The program creates a Picture with the image in the file,
inverts the image vertically and shows the inverted image
on a window.

e5.png is the result saving the image shown after running
java E5 baboon.JPEG

(the file baboon.jpg was included in the zip file).
*/
import java.awt.Color;
public class E5{
  public static void main(String[] args) {
    // Your code here.
    Picture bild = new Picture(args[0]);
    int h = bild.height();
    int w = bild.width();

    Picture newPicture = new Picture(w,h);

    for (int y = h - 1; y >= 0; y--) {
      for (int x = w - 1; x >= 0; x--) {
        newPicture.set(x, y, bild.get(w - x - 1, h - y - 1));
      }
    }
    newPicture.show();
  }
}
