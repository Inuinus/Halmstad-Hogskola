/*
Haar Wavelet
https://en.wikipedia.org/wiki/Haar_wavelet

The Haar wavelet mother function is defined by
     psi(t) = 1 if 0 ≤ t < 1/2,
     psi(t) = -1 if 1/2 ≤ t < 1,
     and psi(t) = 0 otherwise.

For integers n and k, the Haar function is defined by
     phi n k (t) = 2^(n/2) * psi(2^n * t - k).

Complete the two methods below for psi and phi
and complete the program that takes two integer inputs M and N,
and one real input x from the command line and prints phi m n (x).
*/

public class E1{

  public static double psi(double t){
    // Your code here.
    // Remove the
    //     return 0;
    // before placing your code
    double a = 0;
    if (t >= 0 && t < 0.5) {
      a = 1;
    }else if(t >= 0.5 && t < 1){
      a = -1;
    }
    return a;
  }

  public static double phi(int n, int k, double t){
    // Your code here.
    // Remove the
    //     return 0;
    // before placing your code
    double phiA = (Math.pow(2, n/2)) * (psi((Math.pow(2,n)) * t - k));
    return phiA;
  }

  public static void main(String[] args) {
    int m = Integer.parseInt(args[0]);
    int n = Integer.parseInt(args[1]);
    double x = Double.parseDouble(args[2]);
    // Your code here.
    double phi = phi(m, n, x);
    System.out.println(phi);
  }

}
