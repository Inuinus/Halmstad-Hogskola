/*

The program prints the first (positive) odd numbers smaller or equal
than the bound.
The bound is given as a command line argument.
The bound can be any non-negative number.

*/

public class E5{

  public static void main(String[] args) {
      int bound = Integer.parseInt(args[0]);
      System.out.println("The positive odd numbers smaller or equal than "
                          + bound
                          + " are:");
      // your code here
      for (int i = 1; i <= bound ;i += 2) {
        System.out.println(i + "\n");
      }
  }

}
